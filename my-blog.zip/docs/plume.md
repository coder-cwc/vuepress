---
title: plume
author: 你的名字
createTime: 2024/07/02 17:25:38
permalink: /article/xurdn7fo/
---

# Plume 主题

> vuepress-theme-plume 是一个基于 VuePress 的主题。适用于 博客、文档 和 知识笔记 。
