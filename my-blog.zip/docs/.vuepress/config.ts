import { defineUserConfig } from 'vuepress';
import { viteBundler } from '@vuepress/bundler-vite';
import { plumeTheme } from 'vuepress-theme-plume';

export default defineUserConfig({
  // 请不要忘记设置默认语言
  lang: 'zh-CN',
  theme: plumeTheme({
    profile: {
      name: '你的名字',
      description: '描述文字',
      avatar: '/guibook_doload_image.jpg',
      circle: true, // 是否为圆形头像
    },
    navbar: [
      { text: '首页', link: '/', icon: 'material-symbols:home-outline' },
      { text: '博客', link: '/blog/', icon: 'material-symbols:article-outline' },
      {
        text: '笔记',
        icon: 'material-symbols:book-2',
        items: [
          { text: 'TypeScript', link: '/typescript/', icon: 'logos:typescript' },
          {
            text: 'Rust',
            link: '/rust/',
            icon: 'logos:rust',
            items: [
              { text: '简介', link: '/rust/简介/' },
              { text: '快速上手', link: '/rust/快速上手/' },
            ],
          },
        ],
      },
    ],
    notes: {
      dir: '/notes/', // 声明所有笔记的目录
      link: '/', // 声明所有笔记默认的链接前缀， 默认为 '/'
      notes: [
        {
          dir: 'typescript', // 声明笔记的目录，相对于 `notes.dir`
          link: '/typescript/', // 声明笔记的链接前缀
          sidebar: [
            // 配置侧边栏
            {
              text: '简介',
              icon: 'mdi:language-typescript', // 侧边栏图标
              items: ['foo'], // 简化写法，主题会自动补全为 `foo.md`
            },
          ],
        },
        {
          dir: 'rust',
          link: '/rust/',
          sidebar: [
            {
              text: '简介',
              icon: 'mdi:language-typescript', // 侧边栏图标
              items: ['简介', '快速上手'], // 简化写法，主题会自动补全为 `foo.md`
            },
          ],
        },
      ],
    },
  }),
  bundler: viteBundler(),
});
