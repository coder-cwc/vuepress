import {
  isPerformanceSupported,
  now,
  setupDevtoolsPlugin
} from "./chunk-D2YVLGJ5.js";
export {
  isPerformanceSupported,
  now,
  setupDevtoolsPlugin
};
//# sourceMappingURL=@vue_devtools-api.js.map
