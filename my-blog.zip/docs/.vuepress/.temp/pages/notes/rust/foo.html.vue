<template><div><nav class="table-of-contents"><ul><li><router-link to="#learn-rust">Learn Rust</router-link><ul><li><router-link to="#get-started-with-rust">Get started with Rust</router-link></li></ul></li><li><router-link to="#documentation">Documentation</router-link><ul><li><router-link to="#read-the-core-documentation">Read the core documentation</router-link></li></ul></li><li><router-link to="#build-your-skills-in-an-application-domain">Build your skills in an application domain</router-link></li></ul></nav>
<h1 id="rust" tabindex="-1"><a class="header-anchor" href="#rust"><span>Rust</span></a></h1>
<blockquote>
<p>A language empowering everyone to build reliable and efficient software.</p>
</blockquote>
<h2 id="learn-rust" tabindex="-1"><a class="header-anchor" href="#learn-rust"><span>Learn Rust</span></a></h2>
<h3 id="get-started-with-rust" tabindex="-1"><a class="header-anchor" href="#get-started-with-rust"><span>Get started with Rust</span></a></h3>
<p><strong>READ THE BOOK!</strong></p>
<p>Affectionately nicknamed “the book,” The Rust Programming Language will give you an overview of the language from first principles. You’ll build a few projects along the way, and by the end, you’ll have a solid grasp of the language.</p>
<p><strong>DO THE RUSTLINGS COURSE!</strong></p>
<p>Alternatively, Rustlings guides you through downloading and setting up the Rust toolchain, and teaches you the basics of reading and writing Rust syntax, on the command line. It's an alternative to Rust by Example that works with your own environment.</p>
<p><strong>CHECK OUT RUST BY EXAMPLE!</strong>
If reading multiple hundreds of pages about a language isn’t your style, then Rust By Example has you covered. While the book talks about code with a lot of words, RBE shows off a bunch of code, and keeps the talking to a minimum. It also includes exercises!</p>
<h2 id="documentation" tabindex="-1"><a class="header-anchor" href="#documentation"><span>Documentation</span></a></h2>
<h3 id="read-the-core-documentation" tabindex="-1"><a class="header-anchor" href="#read-the-core-documentation"><span>Read the core documentation</span></a></h3>
<p>All of this documentation is also available locally using the rustup doc command, which will open up these resources for you in your browser without requiring a network connection!</p>
<p><strong>THE STANDARD LIBRARY</strong>
Comprehensive guide to the Rust standard library APIs.</p>
<p><strong>EDITION GUIDE</strong>
Guide to the Rust editions.</p>
<p><strong>CARGO BOOK</strong>
A book on Rust’s package manager and build system.</p>
<p><strong>RUSTDOC BOOK</strong>
Learn how to make awesome documentation for your crate.</p>
<p><strong>RUSTC BOOK</strong>
Familiarize yourself with the knobs available in the Rust compiler.</p>
<p><strong>COMPILER ERROR INDEX</strong>
In-depth explanations of the errors you may see from the Rust compiler.</p>
<h2 id="build-your-skills-in-an-application-domain" tabindex="-1"><a class="header-anchor" href="#build-your-skills-in-an-application-domain"><span>Build your skills in an application domain</span></a></h2>
<p><strong>COMMAND LINE BOOK</strong>
Learn how to build effective command line applications in Rust.</p>
<p><strong>WEBASSEMBLY BOOK</strong>
Use Rust to build browser-native libraries through WebAssembly.</p>
<p><strong>EMBEDDED BOOK</strong>
Become proficient with Rust for Microcontrollers and other embedded systems.</p>
</div></template>


