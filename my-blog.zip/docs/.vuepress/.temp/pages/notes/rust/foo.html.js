import comp from "C:/Users/v_cwcochen/Desktop/my-blog/docs/.vuepress/.temp/pages/notes/rust/foo.html.vue"
const data = JSON.parse("{\"path\":\"/notes/rust/foo.html\",\"title\":\"foo\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"foo\",\"author\":\"你的名字\",\"createTime\":\"2024/07/02 17:34:44\",\"head\":[[\"script\",{\"id\":\"check-dark-mode\"},\";(function () {const um= localStorage.getItem('vuepress-theme-appearance') || 'auto';const sm = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;if (um === 'dark' || (um !== 'light' && sm)) {document.documentElement.classList.add('dark');}})();\"],[\"script\",{\"id\":\"check-mac-os\"},\"document.documentElement.classList.toggle('mac', /Mac|iPhone|iPod|iPad/i.test(navigator.platform))\"]]},\"headers\":[{\"level\":2,\"title\":\"Learn Rust\",\"slug\":\"learn-rust\",\"link\":\"#learn-rust\",\"children\":[{\"level\":3,\"title\":\"Get started with Rust\",\"slug\":\"get-started-with-rust\",\"link\":\"#get-started-with-rust\",\"children\":[]}]},{\"level\":2,\"title\":\"Documentation\",\"slug\":\"documentation\",\"link\":\"#documentation\",\"children\":[{\"level\":3,\"title\":\"Read the core documentation\",\"slug\":\"read-the-core-documentation\",\"link\":\"#read-the-core-documentation\",\"children\":[]}]},{\"level\":2,\"title\":\"Build your skills in an application domain\",\"slug\":\"build-your-skills-in-an-application-domain\",\"link\":\"#build-your-skills-in-an-application-domain\",\"children\":[]}],\"readingTime\":{\"minutes\":1.06,\"words\":319},\"filePathRelative\":\"notes/rust/foo.md\",\"categoryList\":[{\"type\":10000,\"name\":\"notes\"},{\"type\":10001,\"name\":\"rust\"}]}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
