<template><div><h1 id="rust" tabindex="-1"><a class="header-anchor" href="#rust"><span>rust</span></a></h1>
</div></template>


