<template><div><h1 id="plume-主题" tabindex="-1"><a class="header-anchor" href="#plume-主题"><span>Plume 主题</span></a></h1>
<blockquote>
<p>vuepress-theme-plume 是一个基于 VuePress 的主题。适用于 博客、文档 和 知识笔记 。</p>
</blockquote>
</div></template>


