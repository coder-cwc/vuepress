import comp from "C:/Users/v_cwcochen/Desktop/my-blog/docs/.vuepress/.temp/pages/rust/n149xjvx/index.html.vue"
const data = JSON.parse("{\"path\":\"/rust/n149xjvx/\",\"title\":\"快速上手\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"快速上手\",\"author\":\"你的名字\",\"createTime\":\"2024/07/02 18:03:37\",\"permalink\":\"/rust/n149xjvx/\",\"head\":[[\"script\",{\"id\":\"check-dark-mode\"},\";(function () {const um= localStorage.getItem('vuepress-theme-appearance') || 'auto';const sm = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;if (um === 'dark' || (um !== 'light' && sm)) {document.documentElement.classList.add('dark');}})();\"],[\"script\",{\"id\":\"check-mac-os\"},\"document.documentElement.classList.toggle('mac', /Mac|iPhone|iPod|iPad/i.test(navigator.platform))\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0.07,\"words\":21},\"filePathRelative\":\"notes/rust/快速上手.md\"}")
export { comp, data }

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
