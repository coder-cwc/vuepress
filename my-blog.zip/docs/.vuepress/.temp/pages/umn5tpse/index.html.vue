<template><div><h1 id="typescript" tabindex="-1"><a class="header-anchor" href="#typescript"><span>typescript</span></a></h1>
</div></template>


