import { defineClientConfig } from 'vuepress/client'
import '@internal/md-power/icons.css'

export default defineClientConfig({
  enhance({ router, app }) {

  }
})
