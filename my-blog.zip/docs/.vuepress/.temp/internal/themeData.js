export const themeData = JSON.parse("{\"locales\":{\"/\":{\"selectLanguageName\":\"简体中文\",\"selectLanguageText\":\"选择语言\",\"appearanceText\":\"外观\",\"lightModeSwitchTitle\":\"切换为浅色主题\",\"darkModeSwitchTitle\":\"切换为深色主题\",\"outlineLabel\":\"此页内容\",\"returnToTopLabel\":\"返回顶部\",\"editLinkText\":\"编辑此页\",\"contributorsText\":\"贡献者\",\"prevPageLabel\":\"上一页\",\"nextPageLabel\":\"下一页\",\"lastUpdated\":{\"text\":\"最后更新于\"},\"notFound\":{\"code\":\"404\",\"title\":\"页面未找到\",\"quote\":\"但是，如果你不改变方向，并且一直寻找，最终可能会到达你要去的地方。\",\"linkText\":\"返回首页\"},\"encryptButtonText\":\"确认\",\"encryptPlaceholder\":\"请输入密码\",\"encryptGlobalText\":\"本站只允许密码访问\",\"encryptPageText\":\"本页面只允许密码访问\",\"footer\":{\"message\":\"Power by <a target=\\\"_blank\\\" href=\\\"https://v2.vuepress.vuejs.org/\\\">VuePress</a> & <a target=\\\"_blank\\\" href=\\\"https://theme-plume.vuejs.press\\\">vuepress-theme-plume</a>\"},\"profile\":{\"name\":\"你的名字\",\"description\":\"描述文字\",\"avatar\":\"/guibook_doload_image.jpg\",\"circle\":true},\"navbar\":[{\"text\":\"首页\",\"link\":\"/\",\"icon\":\"material-symbols:home-outline\"},{\"text\":\"博客\",\"link\":\"/blog/\",\"icon\":\"material-symbols:article-outline\"},{\"text\":\"笔记\",\"icon\":\"material-symbols:book-2\",\"items\":[{\"text\":\"TypeScript\",\"link\":\"/typescript/\",\"icon\":\"logos:typescript\"},{\"text\":\"Rust\",\"link\":\"/rust/\",\"icon\":\"logos:rust\",\"items\":[{\"text\":\"简介\",\"link\":\"/rust/简介/\"},{\"text\":\"快速上手\",\"link\":\"/rust/快速上手/\"}]}]}]}},\"appearance\":true,\"blog\":{\"link\":\"/blog/\",\"pagination\":{\"perPage\":15},\"tags\":true,\"archives\":true,\"tagsLink\":\"/blog/tags/\",\"archivesLink\":\"/blog/archives/\"},\"navbarSocialInclude\":[\"github\",\"twitter\",\"discord\",\"facebook\"],\"aside\":true,\"outline\":[2,3],\"editLink\":true,\"contributors\":true,\"profile\":{\"name\":\"你的名字\",\"description\":\"描述文字\",\"avatar\":\"/guibook_doload_image.jpg\",\"circle\":true}}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateThemeData) {
    __VUE_HMR_RUNTIME__.updateThemeData(themeData)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ themeData }) => {
    __VUE_HMR_RUNTIME__.updateThemeData(themeData)
  })
}
