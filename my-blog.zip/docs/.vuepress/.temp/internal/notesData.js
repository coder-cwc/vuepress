
export const notesData = {
  "/typescript/": [
    {
      "text": "简介",
      "icon": "mdi:language-typescript",
      "items": [
        {
          "text": "foo",
          "link": "/typescript/g9hnvrlb/"
        }
      ]
    }
  ],
  "/rust/": [
    {
      "text": "简介",
      "icon": "mdi:language-typescript",
      "items": [
        {
          "text": "简介",
          "link": "/rust/mfa7jffb/"
        },
        {
          "text": "快速上手",
          "link": "/rust/n149xjvx/"
        }
      ]
    }
  ]
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateNotesData) {
    __VUE_HMR_RUNTIME__.updateNotesData(notesData)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ notesData }) => {
    __VUE_HMR_RUNTIME__.updateNotesData(notesData)
  })
}
