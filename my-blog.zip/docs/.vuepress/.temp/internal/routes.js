export const redirects = JSON.parse("{\"/plume.html\":\"/article/xurdn7fo/\",\"/notes/typescript/foo.html\":\"/typescript/g9hnvrlb/\",\"/notes/rust/\":\"/rust/\",\"/notes/rust/%E5%BF%AB%E9%80%9F%E4%B8%8A%E6%89%8B.html\":\"/rust/n149xjvx/\",\"/notes/rust/%E7%AE%80%E4%BB%8B.html\":\"/rust/mfa7jffb/\"}")

export const routes = Object.fromEntries([
  ["/article/xurdn7fo/", { loader: () => import(/* webpackChunkName: "article_xurdn7fo_index.html" */"C:/Users/v_cwcochen/Desktop/my-blog/docs/.vuepress/.temp/pages/article/xurdn7fo/index.html.js"), meta: {"title":"plume"} }],
  ["/", { loader: () => import(/* webpackChunkName: "index.html" */"C:/Users/v_cwcochen/Desktop/my-blog/docs/.vuepress/.temp/pages/index.html.js"), meta: {"title":""} }],
  ["/typescript/g9hnvrlb/", { loader: () => import(/* webpackChunkName: "typescript_g9hnvrlb_index.html" */"C:/Users/v_cwcochen/Desktop/my-blog/docs/.vuepress/.temp/pages/typescript/g9hnvrlb/index.html.js"), meta: {"title":"foo"} }],
  ["/rust/", { loader: () => import(/* webpackChunkName: "rust_index.html" */"C:/Users/v_cwcochen/Desktop/my-blog/docs/.vuepress/.temp/pages/rust/index.html.js"), meta: {"title":"rust"} }],
  ["/rust/n149xjvx/", { loader: () => import(/* webpackChunkName: "rust_n149xjvx_index.html" */"C:/Users/v_cwcochen/Desktop/my-blog/docs/.vuepress/.temp/pages/rust/n149xjvx/index.html.js"), meta: {"title":"快速上手"} }],
  ["/rust/mfa7jffb/", { loader: () => import(/* webpackChunkName: "rust_mfa7jffb_index.html" */"C:/Users/v_cwcochen/Desktop/my-blog/docs/.vuepress/.temp/pages/rust/mfa7jffb/index.html.js"), meta: {"title":"简介"} }],
  ["/404.html", { loader: () => import(/* webpackChunkName: "404.html" */"C:/Users/v_cwcochen/Desktop/my-blog/docs/.vuepress/.temp/pages/404.html.js"), meta: {"title":""} }],
  ["/blog/", { loader: () => import(/* webpackChunkName: "blog_index.html" */"C:/Users/v_cwcochen/Desktop/my-blog/docs/.vuepress/.temp/pages/blog/index.html.js"), meta: {"title":"博客"} }],
  ["/blog/tags/", { loader: () => import(/* webpackChunkName: "blog_tags_index.html" */"C:/Users/v_cwcochen/Desktop/my-blog/docs/.vuepress/.temp/pages/blog/tags/index.html.js"), meta: {"title":"标签"} }],
  ["/blog/archives/", { loader: () => import(/* webpackChunkName: "blog_archives_index.html" */"C:/Users/v_cwcochen/Desktop/my-blog/docs/.vuepress/.temp/pages/blog/archives/index.html.js"), meta: {"title":"归档"} }],
]);

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateRoutes) {
    __VUE_HMR_RUNTIME__.updateRoutes(routes)
  }
  if (__VUE_HMR_RUNTIME__.updateRedirects) {
    __VUE_HMR_RUNTIME__.updateRedirects(redirects)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ routes, redirects }) => {
    __VUE_HMR_RUNTIME__.updateRoutes(routes)
    __VUE_HMR_RUNTIME__.updateRedirects(redirects)
  })
}
