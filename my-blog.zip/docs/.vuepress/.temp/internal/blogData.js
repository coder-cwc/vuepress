export const blogPostData = [{"path":"/article/xurdn7fo/","title":"plume","categoryList":[],"createTime":"2024/07/02 17:25:38","lang":"zh-CN"}];

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateBlogData) {
    __VUE_HMR_RUNTIME__.updateBlogData(blogPostData)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ blogPostData }) => {
    __VUE_HMR_RUNTIME__.updateBlogData(blogPostData)
  })
}
