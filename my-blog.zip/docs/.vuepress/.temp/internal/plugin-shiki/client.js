
import { useCopyCode } from 'C:/Users/v_cwcochen/Desktop/my-blog/node_modules/.pnpm/@vuepress-plume+plugin-shikiji@1.0.0-rc.72_typescript@5.5.3_vue@3.4.31_typescript@5.5.3__vuep_4izedj4bvobh3z4kjodpiveb3m/node_modules/@vuepress-plume/plugin-shikiji/lib/client/composables/copy-code.js'

export default {
  
  setup() {
    useCopyCode({
      selector: __CC_SELECTOR__,
      duration: __CC_DURATION__,
    })
  },
}
