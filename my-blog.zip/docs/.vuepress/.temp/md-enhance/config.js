import { defineClientConfig } from "vuepress/client";
import CodeTabs from "C:/Users/v_cwcochen/Desktop/my-blog/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.50_katex@0.16.10_markdown-it@14.1.0_typescript@5.5.3_vuep_nm5qodk2zn6y6tbbetnaxr2wdi/node_modules/vuepress-plugin-md-enhance/lib/client/components/CodeTabs.js";
import { hasGlobalComponent } from "C:/Users/v_cwcochen/Desktop/my-blog/node_modules/.pnpm/@vuepress+helper@2.0.0-rc.37_typescript@5.5.3_vuepress@2.0.0-rc.14_@vuepress+bundler-vite@2.0_ullhbhidp744sy3r3ke24tsb4m/node_modules/@vuepress/helper/lib/client/index.js";
import { CodeGroup, CodeGroupItem } from "C:/Users/v_cwcochen/Desktop/my-blog/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.50_katex@0.16.10_markdown-it@14.1.0_typescript@5.5.3_vuep_nm5qodk2zn6y6tbbetnaxr2wdi/node_modules/vuepress-plugin-md-enhance/lib/client/compact/index.js";
import "C:/Users/v_cwcochen/Desktop/my-blog/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.50_katex@0.16.10_markdown-it@14.1.0_typescript@5.5.3_vuep_nm5qodk2zn6y6tbbetnaxr2wdi/node_modules/vuepress-plugin-md-enhance/lib/client/styles/footnote.scss";
import { useHintContainers } from "C:/Users/v_cwcochen/Desktop/my-blog/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.50_katex@0.16.10_markdown-it@14.1.0_typescript@5.5.3_vuep_nm5qodk2zn6y6tbbetnaxr2wdi/node_modules/vuepress-plugin-md-enhance/lib/client/composables/useHintContainers.js";
import "C:/Users/v_cwcochen/Desktop/my-blog/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.50_katex@0.16.10_markdown-it@14.1.0_typescript@5.5.3_vuep_nm5qodk2zn6y6tbbetnaxr2wdi/node_modules/vuepress-plugin-md-enhance/lib/client/styles/hint/index.scss";
import "C:/Users/v_cwcochen/Desktop/my-blog/node_modules/.pnpm/katex@0.16.10/node_modules/katex/dist/katex.min.css";
import "C:/Users/v_cwcochen/Desktop/my-blog/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.50_katex@0.16.10_markdown-it@14.1.0_typescript@5.5.3_vuep_nm5qodk2zn6y6tbbetnaxr2wdi/node_modules/vuepress-plugin-md-enhance/lib/client/styles/katex.scss";
import Tabs from "C:/Users/v_cwcochen/Desktop/my-blog/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.50_katex@0.16.10_markdown-it@14.1.0_typescript@5.5.3_vuep_nm5qodk2zn6y6tbbetnaxr2wdi/node_modules/vuepress-plugin-md-enhance/lib/client/components/Tabs.js";
import "C:/Users/v_cwcochen/Desktop/my-blog/node_modules/.pnpm/vuepress-plugin-md-enhance@2.0.0-rc.50_katex@0.16.10_markdown-it@14.1.0_typescript@5.5.3_vuep_nm5qodk2zn6y6tbbetnaxr2wdi/node_modules/vuepress-plugin-md-enhance/lib/client/styles/tasklist.scss";

export default defineClientConfig({
  enhance: ({ app }) => {
    app.component("CodeTabs", CodeTabs);
    if(!hasGlobalComponent("CodeGroup", app)) app.component("CodeGroup", CodeGroup);
    if(!hasGlobalComponent("CodeGroupItem", app)) app.component("CodeGroupItem", CodeGroupItem);
    app.component("Tabs", Tabs);
  },
  setup: () => {
useHintContainers();
  }
});
