---
title: foo
author: 你的名字
createTime: 2024/07/02 17:34:49
permalink: /typescript/g9hnvrlb/
---
